require("dotenv").config();

exports.jwtSecret = process.env.jwtSecret;
exports.host = process.env.host;
exports.port = process.env.port;
exports.user = process.env.user;
exports.password = process.env.password;
exports.database = process.env.database;
