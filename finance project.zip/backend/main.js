const express = require("express");
// node commonjs

const body_parser = require("body-parser");
const cors = require("cors");

const users_router = require("./users");
const transactions_router = require("./transactions");
const accounts_router = require("./accounts");

let application = express();
application.use(body_parser.json());
application.use(body_parser.urlencoded({ extended: true }));
application.use(cors());

application.use(users_router);
application.use(transactions_router);
application.use(accounts_router);

// 404 Not Found Middleware
application.use((req, res, next) => {
  res.status(404).json({ error: 404, message: "Resource Not Found" });
});

application.listen(4000, (errors) => {
  if (errors) {
    console.log(errors);
  } else {
    console.log("Application started on Port 4000!");
  }
});
