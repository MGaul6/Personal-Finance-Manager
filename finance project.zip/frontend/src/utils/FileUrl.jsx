import { baseFileUrl } from '../shared';
export const fileUrl = (filename) => {
  return `${baseFileUrl}/${filename}`
}