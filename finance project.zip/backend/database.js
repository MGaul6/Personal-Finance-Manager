require("dotenv").config();
const mysql = require("mysql2");
const config = require("./config");

const db = mysql.createConnection({
  host: config.host,
  port: config.port,
  user: config.user,
  password: config.password,
  database: config.database,
  enableKeepAlive: true,
  multipleStatements: true,
});

// https://freedb.tech/dashboard/index.php
db.connect((err) => {
  if (err) {
    console.error("❌ MySQL connection failed:", err);
  } else {
    console.log("✅ MySQL connected");
  }
});

module.exports = db;
